def hello(name):
    return "Hello {0}".format(name)