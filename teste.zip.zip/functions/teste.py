def teste(name):
    pass